
/* ====================
Author: Matthew Connors
Date Started: 12/28/18
File: functions.js
=====================*/

const header = document.body;

document.body.onmousemove = function(e) {
	header.style.backgroundPosition = `-${e.clientX / 20}px -${e.clientY / 20}px`;
}
